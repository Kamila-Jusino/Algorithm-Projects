//Linear Search Algorithm
public class Linear {
    static void linearSearch(int[] arr, int n, int x) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == x)
                return;
        }
    }
}
//credit: UAB Slides