import java.util.*;
import java.io.*;
import java.util.Random;

public class Main {
    ///////////////////File Inputs/READ//////////////////////////////
    // Loading input_1000.txt
    public static int[] readSearchKeys(String filename) throws IOException { //References available on lab report
        List<Integer> keysList = new ArrayList<>();
        InputStream is = Main.class.getResourceAsStream("/" + filename);

        // Reads file
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) { // References available on lab report
            String line;
            while ((line = br.readLine()) != null) {
                String[] numbers = line.split(",");
                for (String number : numbers) {
                    keysList.add(Integer.parseInt(number.trim())); // From Chatgpt
                }
            }
        }

        // List to Array
        int[] keysArray = new int[keysList.size()];
        for (int i = 0; i < keysList.size(); i++) {
            keysArray[i] = keysList.get(i);
        }
        return keysArray;
    }
    public static int[] createData(int size) {
        Random rand = new Random();
        int[] dataset = new int[size];
        for (int i = 0; i < size; i++) {
            dataset[i] = rand.nextInt(1000) + 1; // Numbers between 1 and 1000
        }
        return dataset;
    }

    public static void main(String[] args) throws IOException {
        // Load search keys from file in the src folder
        String filename = "input_1000.txt";
        int[] searchKeys = readSearchKeys(filename);


        int[] sizes = {16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768}; // only to 2^15


        for (int size : sizes) {

            //  Dataset Creation
            int[] dataset = createData(size);

            //////////////////// Linear Search /////////////////////////////////
            long startTime = System.nanoTime();  // Start time for linear search
            for (int key : searchKeys) {
                Linear.linearSearch(dataset, dataset.length, key); // Call to Linear Search
            }
            long linearTime = System.nanoTime() - startTime;  // End time for linear search

            //////////////////// Insertion Sort ////////////////////////////////////
            startTime = System.nanoTime();  // Start time for sorting (Insertion Sort)
            Insertion.insertionSort(dataset);  // Call to Insertion Sort
            long sortTime = System.nanoTime() - startTime;  // End time for sorting

            //////////////////// Binary Search ////////////////////////////////////////
            startTime = System.nanoTime();  // Start time for binary search
            for (int key : searchKeys) {
                Binary.binarySearch(dataset, 0, dataset.length - 1, key); // Call to Binary Search
            }
            long binaryTime = System.nanoTime() - startTime;  // End time for binary search

            //////////////////////// Output Results //////////////////////////////
            System.out.println("Size: " + size);// Self Explanatory :/
            System.out.printf("  Linear Search Time: %.6f ms\n", linearTime / 1e6);// Print linear search time
            System.out.printf("  Insertion Sort Time: %.6f ms\n", sortTime / 1e6); // Print insertion sort time
            System.out.printf("  Binary Search Time: %.6f ms\n", binaryTime / 1e6); // Print binary search time
            System.out.println("---------------------------------------");
        }
    }
}


//File reader help credits: GeekforGeeks "https://www.geeksforgeeks.org/different-ways-reading-text-file-java/", "https://stackoverflow.com/questions/69356108/accessing-a-txt-file-in-the-src-folder"
// Running time help credit: StackOverFlow "https://stackoverflow.com/questions/5204051/how-to-calculate-the-running-time-of-my-program"
// Arrays Help: https://www.geeksforgeeks.org/arrays-in-java/
// Comma Seperator Help: CS 203 Slides Unan
// View Lab Report for the rest