public class SelectionSort {
    public static void selectionSort(int[] A) {
        int N = A.length;

        for (int I = 0; I < N; I++) {
            int smallSub = I;
            for (int J = I + 1; J < N; J++) {
                if (A[J] < A[smallSub]) {
                    smallSub = J;
                }
            }
            // Swap
            int temp = A[I];
            A[I] = A[smallSub];
            A[smallSub] = temp;
        }
    }
}