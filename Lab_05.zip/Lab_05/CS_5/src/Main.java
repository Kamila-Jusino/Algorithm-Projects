import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws IOException {
        String[] fileNames = {
                "input_16.txt",
                "input_32.txt",
                "input_64.txt",
                "input_128.txt",
                "input_256.txt",
                "input_512.txt",
                "input_1024.txt",
                "input_2048.txt",
                "input_4096.txt",
                "input_8192.txt",
                "input_Random.txt",
                "input_ReversedSorted.txt",
                "input_Sorted.txt"
        };

        for (String fileName : fileNames) {
            System.out.println("\n===========================");
            System.out.println("File: " + fileName);
            System.out.println("===============================");
            int[] originalArray = readInputFile(fileName);

            long startTime, endTime;


            // Basic Quick Sort
            int[] quickSortArray = copyArray(originalArray);
            if (fileName.equals("input_16.txt")) {
                System.out.println("\n--- Unsorted Array before QuickSort ---");
                System.out.println(Arrays.toString(quickSortArray));
            }
            startTime = System.nanoTime();
            QuickSort.quickSort(quickSortArray, 0, quickSortArray.length - 1);
            endTime = System.nanoTime();
            System.out.println(" QuickSort Time: " + (endTime - startTime) + " ns");
            if (fileName.equals("input_16.txt")) {
                System.out.println("Array after QuickSort:");
                System.out.println(Arrays.toString(quickSortArray));
            }

            // Randomized Quick Sort
            int[] randomizedQuickSortArray = copyArray(originalArray);
            if (fileName.equals("input_16.txt")) {
                System.out.println("\n--- Unsorted Array before RandomizedQuickSort ---");
                System.out.println(Arrays.toString(randomizedQuickSortArray));
            }
            startTime = System.nanoTime();
            RandomizedQuickSort.randomizedQuickSort(randomizedQuickSortArray, 0, randomizedQuickSortArray.length - 1);
            endTime = System.nanoTime();
            System.out.println("RandomizedQuickSort Time: " + (endTime - startTime) + " ns");
            if (fileName.equals("input_16.txt")) {
                System.out.println("Array after RandomizedQuickSort:");
                System.out.println(Arrays.toString(randomizedQuickSortArray));
            }

            // Selection Sort
            int[] selectionSortArray = copyArray(originalArray);
            if (fileName.equals("input_16.txt")) {
                System.out.println("\n--- Unsorted Array before SelectionSort ---");
                System.out.println(Arrays.toString(selectionSortArray));
            }
            startTime = System.nanoTime();
            SelectionSort.selectionSort(selectionSortArray);
            endTime = System.nanoTime();
            System.out.println("Selection Sort Time: " + (endTime - startTime) + " ns");
            if (fileName.equals("input_16.txt")) {
                System.out.println("Array after SelectionSort:");
                System.out.println(Arrays.toString(selectionSortArray));
            }

            System.out.println();
        }
    }

    // Reads the input file and returns an array of integers
    public static int[] readInputFile(String fileName) throws IOException {
        InputStream is = Main.class.getResourceAsStream("/" + fileName); // Ensure files are in src folder
        List<Integer> keysList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] numbers = line.split("\\s+");
                for (String number : numbers) {
                    if (!number.trim().isEmpty()) {
                        keysList.add(Integer.parseInt(number.trim()));
                    }
                }
            }
        }

        // Convert List<Integer> to int[]
        int[] keysArray = new int[keysList.size()];
        for (int i = 0; i < keysList.size(); i++) {
            keysArray[i] = keysList.get(i);
        }
        return keysArray;
    }

    public static int[] copyArray(int[] original) {
        int[] copy = new int[original.length];
        System.arraycopy(original, 0, copy, 0, original.length);
        return copy;
    }
}
