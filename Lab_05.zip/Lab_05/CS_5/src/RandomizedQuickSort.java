import java.util.Random;

public class RandomizedQuickSort {

    public static void randomizedQuickSort(int[] A, int start, int end) {
        if (start >= end) {
            return; //basr case
        }
        int pivot_idx = randomizedPartition(A, start, end);
        randomizedQuickSort(A, start, pivot_idx - 1);
        randomizedQuickSort(A, pivot_idx + 1, end);
    }
    // randomized partition
    public static int randomizedPartition(int[] A, int start, int end) {
        Random rand = new Random();
        int p = rand.nextInt(end - start + 1) + start;
        swap(A, p, end);
        return partition(A, start, end);
    }

    // partition
    public static int partition(int[] A, int start, int end) {
        int X = A[end];
        int i = start - 1;
        for (int j = start; j < end; j++) {
            if (A[j] <= X) {
                i++;
                swap(A, i, j);
            }
        }
        swap(A, i + 1, end);
        return i + 1;
    }

    // swap
    public static void swap(int[] A, int i, int j) {
        int temp = A[i];
        A[i] = A[j];
        A[j] = temp;
    }
}
